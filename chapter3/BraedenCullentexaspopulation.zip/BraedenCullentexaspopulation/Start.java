import java.io.FileNotFoundException;
/**
 * Write a description of class Start here.
 *
 * @author (Braeden Cullen)
 * @version (10/18/21)
 */
public class Start
{    
    public static void main(String[] args) throws FileNotFoundException {
        new ReadFile(args[0]);
    }

}
