import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Random;

/**
 * Write a description of class population here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class population
{
    // instance variables - replace the example below with your own
    private Scanner scan;
    private Scanner sc;
    private String[] counties; //names of counties
    private int[] population; //population for a county
    private int[] numCon; //number of conties based on starting digit
    private double[] percent; //percent of counties based on starting digit
    private double[] digitPop;
    
    public population() {
        
    }
}
